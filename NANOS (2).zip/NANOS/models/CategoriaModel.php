<?php
class CategoriaModel
{
    private $conn;
    private $table_name = "categorias";

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Crear categoría
    public function crear($data)
    {
        $query = "INSERT INTO " . $this->table_name . " 
                  (id_categoria, nombre) 
                  VALUES (:id_categoria, :nombre)";

        $stmt = $this->conn->prepare($query);

        $data['id_categoria'] = uniqid('CAT_');
        $stmt->bindParam(":id_categoria", $data['id_categoria']);
        $stmt->bindParam(":nombre", $data['nombre']);

        return $stmt->execute();
    }

    // Leer todas las categorías
    public function leer()
    {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY nombre";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Leer una categoría por ID
    public function leerUno($id)
    {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id_categoria = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Actualizar categoría
    public function actualizar($data)
    {
        $query = "UPDATE " . $this->table_name . " 
                  SET nombre = :nombre 
                  WHERE id_categoria = :id_categoria";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":nombre", $data['nombre']);
        $stmt->bindParam(":id_categoria", $data['id_categoria']);

        return $stmt->execute();
    }

    // Eliminar categoría
    public function eliminar($id)
    {
        $query = "DELETE FROM " . $this->table_name . " WHERE id_categoria = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        return $stmt->execute();
    }
}
?>