<?php
class MagnitudModel
{
    private $db;

    public function __construct($database)
    {
        $this->db = $database;
    }

    public function leer()
    {
        $query = "SELECT * FROM magnitudes ORDER BY nombre";
        try {
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            return $stmt;
        } catch (PDOException $e) {
            error_log("Error en leer magnitudes: " . $e->getMessage());
            return false;
        }
    }

    public function leerUno($id)
    {
        $query = "SELECT * FROM magnitudes WHERE id_magnitud = :id";
        try {
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en leerUno magnitud: " . $e->getMessage());
            return false;
        }
    }

    public function crear($data)
    {
        try {
            // Generar ID automático
            $id_magnitud = $this->generarIdMagnitud();

            $query = "INSERT INTO magnitudes (id_magnitud, nombre, abreviatura, tipo) 
                      VALUES (:id_magnitud, :nombre, :abreviatura, :tipo)";

            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id_magnitud', $id_magnitud);
            $stmt->bindParam(':nombre', $data['nombre']);
            $stmt->bindParam(':abreviatura', $data['abreviatura']);
            $stmt->bindParam(':tipo', $data['tipo']);

            if ($stmt->execute()) {
                return ['success' => true, 'id' => $id_magnitud];
            } else {
                return ['success' => false, 'message' => 'Error al ejecutar la consulta'];
            }
        } catch (PDOException $e) {
            error_log("Error en crear magnitud: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function actualizar($data)
    {
        try {
            $query = "UPDATE magnitudes 
                      SET nombre = :nombre, abreviatura = :abreviatura, tipo = :tipo 
                      WHERE id_magnitud = :id_magnitud";

            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id_magnitud', $data['id_magnitud']);
            $stmt->bindParam(':nombre', $data['nombre']);
            $stmt->bindParam(':abreviatura', $data['abreviatura']);
            $stmt->bindParam(':tipo', $data['tipo']);

            if ($stmt->execute()) {
                return ['success' => true];
            } else {
                return ['success' => false, 'message' => 'Error al ejecutar la consulta'];
            }
        } catch (PDOException $e) {
            error_log("Error en actualizar magnitud: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function eliminar($id)
    {
        try {
            // Verificar si la magnitud está siendo usada en productos
            $queryCheck = "SELECT COUNT(*) as count FROM productos WHERE id_magnitud = :id";
            $stmtCheck = $this->db->prepare($queryCheck);
            $stmtCheck->bindParam(':id', $id);
            $stmtCheck->execute();
            $result = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            if ($result['count'] > 0) {
                return ['success' => false, 'message' => 'No se puede eliminar la magnitud porque está siendo usada en productos'];
            }

            $query = "DELETE FROM magnitudes WHERE id_magnitud = :id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id);

            if ($stmt->execute()) {
                return ['success' => true];
            } else {
                return ['success' => false, 'message' => 'Error al ejecutar la consulta'];
            }
        } catch (PDOException $e) {
            error_log("Error en eliminar magnitud: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    private function generarIdMagnitud()
    {
        $query = "SELECT id_magnitud FROM magnitudes ORDER BY id_magnitud DESC LIMIT 1";

        try {
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $lastId = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($lastId) {
                $lastNumber = intval(substr($lastId['id_magnitud'], 4));
                $newNumber = $lastNumber + 1;
                return 'MAG_' . str_pad($newNumber, 2, '0', STR_PAD_LEFT);
            } else {
                return 'MAG_13'; // Continuar desde el último ID existente en la base
            }
        } catch (PDOException $e) {
            error_log("Error en generarIdMagnitud: " . $e->getMessage());
            return 'MAG_13';
        }
    }

    public function obtenerTipos()
    {
        return [
            'peso' => 'Peso',
            'volumen' => 'Volumen',
            'unidad' => 'Unidad',
            'longitud' => 'Longitud',
            'otros' => 'Otros'
        ];
    }
}
?>