<?php
class SubcategoriaModel
{
    private $db;

    public function __construct($database)
    {
        $this->db = $database;
    }

    public function leer()
    {
        $query = "SELECT sc.*, c.nombre as categoria_nombre 
                  FROM subcategorias sc 
                  LEFT JOIN categorias c ON sc.id_categoria = c.id_categoria 
                  ORDER BY c.nombre, sc.nombre";
        try {
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            return $stmt;
        } catch (PDOException $e) {
            error_log("Error en leer subcategorías: " . $e->getMessage());
            return false;
        }
    }

    public function leerUno($id)
    {
        $query = "SELECT sc.*, c.nombre as categoria_nombre 
                  FROM subcategorias sc 
                  LEFT JOIN categorias c ON sc.id_categoria = c.id_categoria 
                  WHERE sc.id_subcategoria = :id";
        try {
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en leerUno subcategoría: " . $e->getMessage());
            return false;
        }
    }

    public function crear($data)
    {
        try {
            // Generar ID automático si no se proporciona
            $id_subcategoria = $data['id_subcategoria'] ?: $this->generarIdSubcategoria();

            $query = "INSERT INTO subcategorias (id_subcategoria, id_categoria, nombre, descripcion) 
                      VALUES (:id_subcategoria, :id_categoria, :nombre, :descripcion)";

            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id_subcategoria', $id_subcategoria);
            $stmt->bindParam(':id_categoria', $data['id_categoria']);
            $stmt->bindParam(':nombre', $data['nombre']);
            $stmt->bindParam(':descripcion', $data['descripcion']);

            if ($stmt->execute()) {
                return ['success' => true, 'id' => $id_subcategoria];
            } else {
                return ['success' => false, 'message' => 'Error al ejecutar la consulta'];
            }
        } catch (PDOException $e) {
            error_log("Error en crear subcategoría: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function actualizar($data)
    {
        try {
            $query = "UPDATE subcategorias 
                      SET id_categoria = :id_categoria, 
                          nombre = :nombre, 
                          descripcion = :descripcion 
                      WHERE id_subcategoria = :id_subcategoria";

            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id_subcategoria', $data['id_subcategoria']);
            $stmt->bindParam(':id_categoria', $data['id_categoria']);
            $stmt->bindParam(':nombre', $data['nombre']);
            $stmt->bindParam(':descripcion', $data['descripcion']);

            if ($stmt->execute()) {
                return ['success' => true];
            } else {
                return ['success' => false, 'message' => 'Error al ejecutar la consulta'];
            }
        } catch (PDOException $e) {
            error_log("Error en actualizar subcategoría: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function eliminar($id)
    {
        try {
            // Verificar si la subcategoría está siendo usada en productos
            $queryCheck = "SELECT COUNT(*) as count FROM productos WHERE id_subcategoria = :id";
            $stmtCheck = $this->db->prepare($queryCheck);
            $stmtCheck->bindParam(':id', $id);
            $stmtCheck->execute();
            $result = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            if ($result['count'] > 0) {
                return ['success' => false, 'message' => 'No se puede eliminar la subcategoría porque está siendo usada en productos'];
            }

            $query = "DELETE FROM subcategorias WHERE id_subcategoria = :id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id);

            if ($stmt->execute()) {
                return ['success' => true];
            } else {
                return ['success' => false, 'message' => 'Error al ejecutar la consulta'];
            }
        } catch (PDOException $e) {
            error_log("Error en eliminar subcategoría: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function obtenerCategorias()
    {
        $query = "SELECT id_categoria, nombre FROM categorias ORDER BY nombre";
        try {
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            return $stmt;
        } catch (PDOException $e) {
            error_log("Error en obtenerCategorias: " . $e->getMessage());
            return false;
        }
    }

    private function generarIdSubcategoria()
    {
        $query = "SELECT id_subcategoria FROM subcategorias ORDER BY id_subcategoria DESC LIMIT 1";

        try {
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $lastId = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($lastId) {
                $lastNumber = intval(substr($lastId['id_subcategoria'], 4));
                $newNumber = $lastNumber + 1;
                return 'SUB_' . str_pad($newNumber, 2, '0', STR_PAD_LEFT);
            } else {
                return 'SUB_01';
            }
        } catch (PDOException $e) {
            error_log("Error en generarIdSubcategoria: " . $e->getMessage());
            return 'SUB_01';
        }
    }
}
?>