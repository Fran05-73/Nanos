<?php
class ProductoModel
{
    private $conn;
    private $table_name = "productos";

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Crear producto
    public function crear($data)
    {
        try {
            $this->conn->beginTransaction();

            $query = "INSERT INTO " . $this->table_name . " 
                      (id_producto, nombre, codigo, descripcion, precio_venta, 
                       stock, id_categoria, id_subcategoria, id_proveedores, peso, id_magnitud, fecha_vencimiento) 
                      VALUES (:id_producto, :nombre, :codigo, :descripcion, :precio_venta, 
                              :stock, :id_categoria, :id_subcategoria, :id_proveedores, :peso, :id_magnitud, :fecha_vencimiento)";

            $stmt = $this->conn->prepare($query);

            $data['id_producto'] = uniqid('PROD_');

            // Convertir valores vacíos a NULL
            $id_categoria = !empty($data['id_categoria']) ? $data['id_categoria'] : null;
            $id_subcategoria = !empty($data['id_subcategoria']) ? $data['id_subcategoria'] : null;
            $id_proveedores = !empty($data['id_proveedores']) ? $data['id_proveedores'] : null;
            $id_magnitud = !empty($data['id_magnitud']) ? $data['id_magnitud'] : null;
            $peso = !empty($data['peso']) ? $data['peso'] : null;
            $codigo = !empty($data['codigo']) ? $data['codigo'] : null;
            $descripcion = !empty($data['descripcion']) ? $data['descripcion'] : null;

            $stmt->bindParam(":id_producto", $data['id_producto']);
            $stmt->bindParam(":nombre", $data['nombre']);
            $stmt->bindParam(":codigo", $codigo);
            $stmt->bindParam(":descripcion", $descripcion);
            $stmt->bindParam(":precio_venta", $data['precio_venta']);
            $stmt->bindParam(":stock", $data['stock']);
            $stmt->bindParam(":id_categoria", $id_categoria);
            $stmt->bindParam(":id_subcategoria", $id_subcategoria);
            $stmt->bindParam(":id_proveedores", $id_proveedores);
            $stmt->bindParam(":peso", $peso);
            $stmt->bindParam(":id_magnitud", $id_magnitud);
            $stmt->bindParam(":fecha_vencimiento", $data['fecha_vencimiento']);

            if (!$stmt->execute()) {
                throw new Exception("Error al crear producto");
            }

            $this->conn->commit();
            return ['success' => true, 'id_producto' => $data['id_producto']];

        } catch (Exception $e) {
            $this->conn->rollBack();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // Leer todos los productos con información relacionada
    public function leer()
    {
        $query = "SELECT p.*, 
                         c.nombre as categoria_nombre, 
                         s.nombre as subcategoria_nombre,
                         pr.nombre as proveedor_nombre, 
                         m.nombre as magnitud_nombre,
                         m.abreviatura as magnitud_abreviatura
                  FROM " . $this->table_name . " p
                  LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
                  LEFT JOIN subcategorias s ON p.id_subcategoria = s.id_subcategoria
                  LEFT JOIN proveedores pr ON p.id_proveedores = pr.id_proveedores
                  LEFT JOIN magnitudes m ON p.id_magnitud = m.id_magnitud
                  ORDER BY p.nombre";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Leer un producto por ID
    public function leerUno($id)
    {
        $query = "SELECT p.*, 
                         c.nombre as categoria_nombre, 
                         s.nombre as subcategoria_nombre,
                         pr.nombre as proveedor_nombre, 
                         m.nombre as magnitud_nombre
                  FROM " . $this->table_name . " p
                  LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
                  LEFT JOIN subcategorias s ON p.id_subcategoria = s.id_subcategoria
                  LEFT JOIN proveedores pr ON p.id_proveedores = pr.id_proveedores
                  LEFT JOIN magnitudes m ON p.id_magnitud = m.id_magnitud
                  WHERE p.id_producto = ? 
                  LIMIT 0,1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Actualizar producto
    public function actualizar($data)
    {
        try {
            $this->conn->beginTransaction();

            $query = "UPDATE " . $this->table_name . " 
                      SET nombre = :nombre, codigo = :codigo, descripcion = :descripcion, 
                          precio_venta = :precio_venta, stock = :stock, 
                          id_categoria = :id_categoria, id_subcategoria = :id_subcategoria,
                          id_proveedores = :id_proveedores, peso = :peso, id_magnitud = :id_magnitud,
                          fecha_vencimiento = :fecha_vencimiento
                      WHERE id_producto = :id_producto";

            $stmt = $this->conn->prepare($query);

            // Convertir valores vacíos a NULL
            $id_categoria = !empty($data['id_categoria']) ? $data['id_categoria'] : null;
            $id_subcategoria = !empty($data['id_subcategoria']) ? $data['id_subcategoria'] : null;
            $id_proveedores = !empty($data['id_proveedores']) ? $data['id_proveedores'] : null;
            $id_magnitud = !empty($data['id_magnitud']) ? $data['id_magnitud'] : null;
            $peso = !empty($data['peso']) ? $data['peso'] : null;
            $codigo = !empty($data['codigo']) ? $data['codigo'] : null;
            $descripcion = !empty($data['descripcion']) ? $data['descripcion'] : null;

            $stmt->bindParam(":nombre", $data['nombre']);
            $stmt->bindParam(":codigo", $codigo);
            $stmt->bindParam(":descripcion", $descripcion);
            $stmt->bindParam(":precio_venta", $data['precio_venta']);
            $stmt->bindParam(":stock", $data['stock']);
            $stmt->bindParam(":id_categoria", $id_categoria);
            $stmt->bindParam(":id_subcategoria", $id_subcategoria);
            $stmt->bindParam(":id_proveedores", $id_proveedores);
            $stmt->bindParam(":peso", $peso);
            $stmt->bindParam(":id_magnitud", $id_magnitud);
            $stmt->bindParam(":fecha_vencimiento", $data['fecha_vencimiento']);
            $stmt->bindParam(":id_producto", $data['id_producto']);

            if (!$stmt->execute()) {
                throw new Exception("Error al actualizar producto");
            }

            $this->conn->commit();
            return ['success' => true];

        } catch (Exception $e) {
            $this->conn->rollBack();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // Eliminar producto
    public function eliminar($id)
    {
        $query = "DELETE FROM " . $this->table_name . " WHERE id_producto = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        return $stmt->execute();
    }

    // Obtener categorías para dropdown
    public function obtenerCategorias()
    {
        $query = "SELECT id_categoria, nombre FROM categorias ORDER BY nombre";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Obtener subcategorías por categoría
    public function obtenerSubcategorias($id_categoria)
    {
        $query = "SELECT id_subcategoria, nombre FROM subcategorias 
                  WHERE id_categoria = ? 
                  ORDER BY nombre";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id_categoria);
        $stmt->execute();
        return $stmt;
    }

    // Obtener proveedores para dropdown
    public function obtenerProveedores()
    {
        $query = "SELECT id_proveedores, nombre FROM proveedores ORDER BY nombre";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Obtener magnitudes para dropdown
    public function obtenerMagnitudes()
    {
        $query = "SELECT id_magnitud, nombre, abreviatura FROM magnitudes ORDER BY nombre";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Agregar nueva categoría
    public function agregarCategoria($nombre)
    {
        try {
            $query = "INSERT INTO categorias (id_categoria, nombre) 
                      VALUES (:id_categoria, :nombre)";

            $stmt = $this->conn->prepare($query);
            $id_categoria = uniqid('CAT_');

            $stmt->bindParam(":id_categoria", $id_categoria);
            $stmt->bindParam(":nombre", $nombre);

            if ($stmt->execute()) {
                return ['success' => true, 'id' => $id_categoria];
            } else {
                throw new Exception("Error al insertar categoría");
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // Agregar nueva subcategoría
    public function agregarSubcategoria($data)
    {
        try {
            $query = "INSERT INTO subcategorias (id_subcategoria, id_categoria, nombre, descripcion) 
                      VALUES (:id_subcategoria, :id_categoria, :nombre, :descripcion)";

            $stmt = $this->conn->prepare($query);
            $id_subcategoria = uniqid('SUB_');

            $stmt->bindParam(":id_subcategoria", $id_subcategoria);
            $stmt->bindParam(":id_categoria", $data['id_categoria']);
            $stmt->bindParam(":nombre", $data['nombre']);
            $stmt->bindParam(":descripcion", $data['descripcion']);

            if ($stmt->execute()) {
                return ['success' => true, 'id' => $id_subcategoria];
            } else {
                throw new Exception("Error al insertar subcategoría");
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // Agregar nuevo proveedor
    public function agregarProveedor($data)
    {
        try {
            $query = "INSERT INTO proveedores (id_proveedores, nombre, telefono_principal, email_principal, direccion) 
                      VALUES (:id_proveedores, :nombre, :telefono_principal, :email_principal, :direccion)";

            $stmt = $this->conn->prepare($query);
            $id_proveedores = uniqid('PROV_');

            $stmt->bindParam(":id_proveedores", $id_proveedores);
            $stmt->bindParam(":nombre", $data['nombre']);
            $stmt->bindParam(":telefono_principal", $data['telefono_principal']);
            $stmt->bindParam(":email_principal", $data['email_principal']);
            $stmt->bindParam(":direccion", $data['direccion']);

            if ($stmt->execute()) {
                return ['success' => true, 'id' => $id_proveedores];
            } else {
                throw new Exception("Error al insertar proveedor");
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // Agregar nueva magnitud
    public function agregarMagnitud($data)
    {
        try {
            $query = "INSERT INTO magnitudes (id_magnitud, nombre, abreviatura, tipo) 
                      VALUES (:id_magnitud, :nombre, :abreviatura, :tipo)";

            $stmt = $this->conn->prepare($query);
            $id_magnitud = uniqid('MAG_');

            $stmt->bindParam(":id_magnitud", $id_magnitud);
            $stmt->bindParam(":nombre", $data['nombre']);
            $stmt->bindParam(":abreviatura", $data['abreviatura']);
            $stmt->bindParam(":tipo", $data['tipo']);

            if ($stmt->execute()) {
                return ['success' => true, 'id' => $id_magnitud];
            } else {
                throw new Exception("Error al insertar magnitud");
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
?>