<?php
class ProveedorModel
{
    private $conn;
    private $table_name = "proveedores";

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Crear proveedor
    public function crear($data)
    {
        try {
            $this->conn->beginTransaction();

            // Insertar proveedor principal
            $query = "INSERT INTO " . $this->table_name . " 
                      (id_proveedores, nombre, telefono_principal, direccion, email_principal) 
                      VALUES (:id_proveedores, :nombre, :telefono_principal, :direccion, :email_principal)";

            $stmt = $this->conn->prepare($query);

            // Generar ID único
            $id_proveedores = uniqid('PROV_');

            $stmt->bindParam(":id_proveedores", $id_proveedores);
            $stmt->bindParam(":nombre", $data['nombre']);
            $stmt->bindParam(":telefono_principal", $data['telefono_principal']);
            $stmt->bindParam(":direccion", $data['direccion']);
            $stmt->bindParam(":email_principal", $data['email_principal']);

            if (!$stmt->execute()) {
                throw new Exception("Error al crear proveedor principal");
            }

            // Insertar teléfonos adicionales
            if (!empty($data['telefonos_adicionales'])) {
                foreach ($data['telefonos_adicionales'] as $telefono) {
                    $query_telefono = "INSERT INTO telefonos 
                                      (id_telefono, numero, tipo, id_proveedor) 
                                      VALUES (:id_telefono, :numero, :tipo, :id_proveedor)";

                    $stmt_telefono = $this->conn->prepare($query_telefono);
                    $id_telefono = uniqid('TEL_');

                    $stmt_telefono->bindParam(":id_telefono", $id_telefono);
                    $stmt_telefono->bindParam(":numero", $telefono['numero']);
                    $stmt_telefono->bindParam(":tipo", $telefono['tipo']);
                    $stmt_telefono->bindParam(":id_proveedor", $id_proveedores);

                    if (!$stmt_telefono->execute()) {
                        throw new Exception("Error al insertar teléfono adicional");
                    }
                }
            }

            // Insertar emails adicionales
            if (!empty($data['emails_adicionales'])) {
                foreach ($data['emails_adicionales'] as $email) {
                    $query_email = "INSERT INTO emails 
                                   (id_email, correo, tipo, id_proveedor) 
                                   VALUES (:id_email, :correo, :tipo, :id_proveedor)";

                    $stmt_email = $this->conn->prepare($query_email);
                    $id_email = uniqid('EMAIL_');

                    $stmt_email->bindParam(":id_email", $id_email);
                    $stmt_email->bindParam(":correo", $email['correo']);
                    $stmt_email->bindParam(":tipo", $email['tipo']);
                    $stmt_email->bindParam(":id_proveedor", $id_proveedores);

                    if (!$stmt_email->execute()) {
                        throw new Exception("Error al insertar email adicional");
                    }
                }
            }

            $this->conn->commit();
            return ['success' => true, 'id_proveedor' => $id_proveedores];

        } catch (Exception $e) {
            $this->conn->rollBack();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // Leer todos los proveedores
    public function leer()
    {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY nombre";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Leer un proveedor por ID con teléfonos y emails adicionales
    public function leerUno($id)
    {
        try {
            // Obtener datos del proveedor principal
            $query = "SELECT * FROM " . $this->table_name . " WHERE id_proveedores = ? LIMIT 0,1";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $id);
            $stmt->execute();

            $proveedor = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$proveedor) {
                return false;
            }

            // Obtener teléfonos adicionales
            $proveedor['telefonos_adicionales'] = $this->obtenerTelefonosProveedor($id)->fetchAll(PDO::FETCH_ASSOC);

            // Obtener emails adicionales
            $proveedor['emails_adicionales'] = $this->obtenerEmailsProveedor($id)->fetchAll(PDO::FETCH_ASSOC);

            return $proveedor;

        } catch (Exception $e) {
            return false;
        }
    }

    // Obtener teléfonos de un proveedor
    public function obtenerTelefonosProveedor($id_proveedor)
    {
        $query = "SELECT * FROM telefonos WHERE id_proveedor = ? ORDER BY tipo";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id_proveedor);
        $stmt->execute();
        return $stmt;
    }

    // Obtener emails de un proveedor
    public function obtenerEmailsProveedor($id_proveedor)
    {
        $query = "SELECT * FROM emails WHERE id_proveedor = ? ORDER BY tipo";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id_proveedor);
        $stmt->execute();
        return $stmt;
    }

    // Actualizar proveedor
    public function actualizar($data)
    {
        try {
            $this->conn->beginTransaction();

            // Actualizar proveedor principal
            $query = "UPDATE " . $this->table_name . " 
                      SET nombre = :nombre, telefono_principal = :telefono_principal, 
                          direccion = :direccion, email_principal = :email_principal 
                      WHERE id_proveedores = :id_proveedores";

            $stmt = $this->conn->prepare($query);

            $stmt->bindParam(":nombre", $data['nombre']);
            $stmt->bindParam(":telefono_principal", $data['telefono_principal']);
            $stmt->bindParam(":direccion", $data['direccion']);
            $stmt->bindParam(":email_principal", $data['email_principal']);
            $stmt->bindParam(":id_proveedores", $data['id_proveedores']);

            if (!$stmt->execute()) {
                throw new Exception("Error al actualizar proveedor principal");
            }

            // Eliminar teléfonos existentes y agregar nuevos
            $this->eliminarTelefonosProveedor($data['id_proveedores']);
            if (!empty($data['telefonos_adicionales'])) {
                foreach ($data['telefonos_adicionales'] as $telefono) {
                    $query_telefono = "INSERT INTO telefonos 
                                      (id_telefono, numero, tipo, id_proveedor) 
                                      VALUES (:id_telefono, :numero, :tipo, :id_proveedor)";

                    $stmt_telefono = $this->conn->prepare($query_telefono);
                    $id_telefono = uniqid('TEL_');

                    $stmt_telefono->bindParam(":id_telefono", $id_telefono);
                    $stmt_telefono->bindParam(":numero", $telefono['numero']);
                    $stmt_telefono->bindParam(":tipo", $telefono['tipo']);
                    $stmt_telefono->bindParam(":id_proveedor", $data['id_proveedores']);

                    if (!$stmt_telefono->execute()) {
                        throw new Exception("Error al actualizar teléfono adicional");
                    }
                }
            }

            // Eliminar emails existentes y agregar nuevos
            $this->eliminarEmailsProveedor($data['id_proveedores']);
            if (!empty($data['emails_adicionales'])) {
                foreach ($data['emails_adicionales'] as $email) {
                    $query_email = "INSERT INTO emails 
                                   (id_email, correo, tipo, id_proveedor) 
                                   VALUES (:id_email, :correo, :tipo, :id_proveedor)";

                    $stmt_email = $this->conn->prepare($query_email);
                    $id_email = uniqid('EMAIL_');

                    $stmt_email->bindParam(":id_email", $id_email);
                    $stmt_email->bindParam(":correo", $email['correo']);
                    $stmt_email->bindParam(":tipo", $email['tipo']);
                    $stmt_email->bindParam(":id_proveedor", $data['id_proveedores']);

                    if (!$stmt_email->execute()) {
                        throw new Exception("Error al actualizar email adicional");
                    }
                }
            }

            $this->conn->commit();
            return ['success' => true];

        } catch (Exception $e) {
            $this->conn->rollBack();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // Eliminar teléfonos de un proveedor
    private function eliminarTelefonosProveedor($id_proveedor)
    {
        $query = "DELETE FROM telefonos WHERE id_proveedor = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id_proveedor);
        return $stmt->execute();
    }

    // Eliminar emails de un proveedor
    private function eliminarEmailsProveedor($id_proveedor)
    {
        $query = "DELETE FROM emails WHERE id_proveedor = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id_proveedor);
        return $stmt->execute();
    }

    // Eliminar proveedor
    public function eliminar($id)
    {
        try {
            $this->conn->beginTransaction();

            // Eliminar teléfonos asociados
            $this->eliminarTelefonosProveedor($id);

            // Eliminar emails asociados
            $this->eliminarEmailsProveedor($id);

            // Eliminar proveedor
            $query = "DELETE FROM " . $this->table_name . " WHERE id_proveedores = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $id);

            $result = $stmt->execute();

            if ($result) {
                $this->conn->commit();
                return true;
            } else {
                $this->conn->rollBack();
                return false;
            }

        } catch (Exception $e) {
            $this->conn->rollBack();
            return false;
        }
    }
}
?>