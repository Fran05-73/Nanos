<?php
include_once '../../config/database.php';
include_once '../../models/MagnitudModel.php';

$database = new Database();
$db = $database->getConnection();
$model = new MagnitudModel($db);
$magnitudes = $model->leer();
$tipos = $model->obtenerTipos();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Magnitudes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .badge-tipo {
            font-size: 0.75em;
        }

        .table-actions {
            white-space: nowrap;
        }
    </style>
</head>

<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-weight me-2"></i>Gestión de Magnitudes</h2>
            <a href="../../" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i>Volver al Inicio
            </a>
        </div>

        <!-- Formulario para crear/editar -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0" id="form-title">
                    <i class="fas fa-plus-circle me-2"></i>Nueva Magnitud
                </h5>
            </div>
            <div class="card-body">
                <form id="magnitud-form">
                    <input type="hidden" id="magnitud-id" name="id">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Nombre *</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required
                                    placeholder="Ej: Kilogramos, Litros, Unidad">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label class="form-label">Abreviatura *</label>
                                <input type="text" class="form-control" id="abreviatura" name="abreviatura" required
                                    placeholder="Ej: kg, L, u" maxlength="10">
                                <div class="form-text">Máximo 10 caracteres</div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label class="form-label">Tipo *</label>
                                <select class="form-select" id="tipo" name="tipo" required>
                                    <option value="">Seleccionar tipo</option>
                                    <?php foreach ($tipos as $valor => $texto): ?>
                                        <option value="<?= $valor ?>"><?= $texto ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="mb-3">
                                <label class="form-label">&nbsp;</label>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-save me-1"></i>Guardar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <button type="button" class="btn btn-secondary" onclick="limpiarFormulario()">
                            <i class="fas fa-times me-1"></i>Cancelar
                        </button>
                        <div id="mensaje-validacion" class="text-danger small"></div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tabla de magnitudes -->
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Lista de Magnitudes</h5>
            </div>
            <div class="card-body">
                <?php if ($magnitudes && $magnitudes->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Abreviatura</th>
                                    <th>Tipo</th>
                                    <th width="120" class="text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $magnitudes->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td><code><?= $row['id_magnitud'] ?></code></td>
                                        <td>
                                            <strong><?= htmlspecialchars($row['nombre']) ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?= $row['abreviatura'] ?></span>
                                        </td>
                                        <td>
                                            <?php
                                            $badgeClass = match ($row['tipo']) {
                                                'peso' => 'bg-warning',
                                                'volumen' => 'bg-primary',
                                                'unidad' => 'bg-success',
                                                'longitud' => 'bg-info',
                                                default => 'bg-secondary'
                                            };
                                            ?>
                                            <span class="badge <?= $badgeClass ?> badge-tipo">
                                                <?= $tipos[$row['tipo']] ?? $row['tipo'] ?>
                                            </span>
                                        </td>
                                        <td class="table-actions text-center">
                                            <button class="btn btn-sm btn-warning me-1"
                                                onclick="editarMagnitud('<?= $row['id_magnitud'] ?>')" title="Editar magnitud">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger"
                                                onclick="eliminarMagnitud('<?= $row['id_magnitud'] ?>')"
                                                title="Eliminar magnitud">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle me-2"></i>No hay magnitudes registradas.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Enfocar el campo nombre al cargar la página
        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('nombre').focus();
        });

        // Manejar envío del formulario
        document.getElementById('magnitud-form').addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(this);
            const id = document.getElementById('magnitud-id').value;
            formData.append('accion', id ? 'actualizar' : 'crear');

            // Validación básica
            const nombre = document.getElementById('nombre').value.trim();
            const abreviatura = document.getElementById('abreviatura').value.trim();
            const tipo = document.getElementById('tipo').value;

            if (!nombre) {
                alert('Por favor ingrese el nombre de la magnitud');
                document.getElementById('nombre').focus();
                return;
            }

            if (!abreviatura) {
                alert('Por favor ingrese la abreviatura');
                document.getElementById('abreviatura').focus();
                return;
            }

            if (!tipo) {
                alert('Por favor seleccione el tipo');
                document.getElementById('tipo').focus();
                return;
            }

            fetch('../../controllers/MagnitudController.php', {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al procesar la solicitud: ' + error.message);
                });
        });

        function editarMagnitud(id) {
            console.log('Editando magnitud ID:', id);

            fetch('../../controllers/MagnitudController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'accion=obtener&id=' + encodeURIComponent(id)
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor: ' + response.status);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Datos recibidos:', data);

                    if (data.success === false) {
                        throw new Error(data.message || 'Error al obtener los datos');
                    }

                    if (data && data.id_magnitud) {
                        document.getElementById('magnitud-id').value = data.id_magnitud;
                        document.getElementById('nombre').value = data.nombre || '';
                        document.getElementById('abreviatura').value = data.abreviatura || '';
                        document.getElementById('tipo').value = data.tipo || '';

                        document.getElementById('form-title').innerHTML = '<i class="fas fa-edit me-2"></i>Editar Magnitud';
                        document.getElementById('nombre').focus();
                    } else {
                        throw new Error('Datos de la magnitud no encontrados');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al cargar los datos de la magnitud: ' + error.message);
                });
        }

        function eliminarMagnitud(id) {
            if (confirm('¿Está seguro de eliminar esta magnitud?\n\nNota: No se podrá eliminar si está siendo usada en productos.')) {
                fetch('../../controllers/MagnitudController.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'accion=eliminar&id=' + id
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error en la respuesta del servidor');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            alert(data.message);
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error al eliminar la magnitud: ' + error.message);
                    });
            }
        }

        function limpiarFormulario() {
            document.getElementById('magnitud-form').reset();
            document.getElementById('magnitud-id').value = '';
            document.getElementById('form-title').innerHTML = '<i class="fas fa-plus-circle me-2"></i>Nueva Magnitud';
            document.getElementById('mensaje-validacion').textContent = '';
            document.getElementById('nombre').focus();
        }

        // Validar abreviatura en tiempo real
        document.getElementById('abreviatura').addEventListener('input', function () {
            const abreviatura = this.value.trim();
            const mensaje = document.getElementById('mensaje-validacion');

            if (abreviatura.length > 10) {
                mensaje.textContent = 'La abreviatura no puede tener más de 10 caracteres';
                this.value = abreviatura.substring(0, 10);
            } else {
                mensaje.textContent = '';
            }
        });
    </script>
</body>

</html>