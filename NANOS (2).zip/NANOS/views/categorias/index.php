<?php
include_once '../../config/database.php';
include_once '../../models/CategoriaModel.php';

$database = new Database();
$db = $database->getConnection();
$model = new CategoriaModel($db);
$categorias = $model->leer();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Categorías</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-tags me-2"></i>Gestión de Categorías</h2>
            <a href="../../" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i>Volver al Inicio
            </a>
        </div>

        <!-- Formulario para crear/editar -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0" id="form-title">
                    <i class="fas fa-plus-circle me-2"></i>Nueva Categoría
                </h5>
            </div>
            <div class="card-body">
                <form id="categoria-form">
                    <input type="hidden" id="categoria-id" name="id">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label class="form-label">Nombre de la Categoría *</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required
                                    placeholder="Ingrese el nombre de la categoría">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3 d-flex align-items-end h-100">
                                <button type="submit" class="btn btn-success me-2">
                                    <i class="fas fa-save me-1"></i>Guardar
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="limpiarFormulario()">
                                    <i class="fas fa-times me-1"></i>Cancelar
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tabla de categorías -->
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Lista de Categorías</h5>
            </div>
            <div class="card-body">
                <?php if ($categorias->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th width="150">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $categorias->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td><code><?php echo $row['id_categoria']; ?></code></td>
                                        <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-warning me-1"
                                                onclick="editarCategoria('<?php echo $row['id_categoria']; ?>')"
                                                title="Editar categoría">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger"
                                                onclick="eliminarCategoria('<?php echo $row['id_categoria']; ?>')"
                                                title="Eliminar categoría">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle me-2"></i>No hay categorías registradas.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Manejar envío del formulario
        document.getElementById('categoria-form').addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(this);
            const id = document.getElementById('categoria-id').value;
            formData.append('accion', id ? 'actualizar' : 'crear');

            // Validación básica
            const nombre = document.getElementById('nombre').value.trim();
            if (!nombre) {
                alert('Por favor ingrese el nombre de la categoría');
                return;
            }

            fetch('../../controllers/CategoriaController.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al procesar la solicitud');
                });
        });

        function editarCategoria(id) {
            fetch('../../controllers/CategoriaController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'accion=obtener&id=' + id
            })
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        document.getElementById('categoria-id').value = data.id_categoria;
                        document.getElementById('nombre').value = data.nombre;
                        document.getElementById('form-title').innerHTML = '<i class="fas fa-edit me-2"></i>Editar Categoría';
                        document.getElementById('nombre').focus();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al cargar los datos de la categoría');
                });
        }

        function eliminarCategoria(id) {
            if (confirm('¿Está seguro de eliminar esta categoría?\n\nEsta acción no se puede deshacer.')) {
                fetch('../../controllers/CategoriaController.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'accion=eliminar&id=' + id
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(data.message);
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error al eliminar la categoría');
                    });
            }
        }

        function limpiarFormulario() {
            document.getElementById('categoria-form').reset();
            document.getElementById('categoria-id').value = '';
            document.getElementById('form-title').innerHTML = '<i class="fas fa-plus-circle me-2"></i>Nueva Categoría';
            document.getElementById('nombre').focus();
        }

        // Enfocar el campo nombre al cargar la página
        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('nombre').focus();
        });
    </script>
</body>

</html>