<?php
include_once '../../config/database.php';
include_once '../../models/ProveedorModel.php';

$database = new Database();
$db = $database->getConnection();
$model = new ProveedorModel($db);
$proveedores = $model->leer();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Proveedores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-truck me-2"></i>Gestión de Proveedores</h2>
            <a href="../../" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i>Volver al Inicio
            </a>
        </div>

        <!-- Formulario para crear/editar -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0" id="form-title">
                    <i class="fas fa-plus-circle me-2"></i>Nuevo Proveedor
                </h5>
            </div>
            <div class="card-body">
                <form id="proveedor-form">
                    <input type="hidden" id="proveedor-id" name="id">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Nombre *</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required
                                    placeholder="Ingrese el nombre del proveedor">
                            </div>

                            <!-- Teléfonos -->
                            <div class="mb-3">
                                <label class="form-label">Teléfono Principal</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                    <input type="text" class="form-control" id="telefono_principal"
                                        name="telefono_principal" placeholder="Número de teléfono principal">
                                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#telefonoModal">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                                <!-- Lista de teléfonos adicionales -->
                                <div id="telefonos-adicionales" class="mt-2"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Dirección</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                                    <input type="text" class="form-control" id="direccion" name="direccion"
                                        placeholder="Dirección del proveedor">
                                </div>
                            </div>

                            <!-- Emails -->
                            <div class="mb-3">
                                <label class="form-label">Email Principal</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                    <input type="email" class="form-control" id="email_principal" name="email_principal"
                                        placeholder="correo@ejemplo.com">
                                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#emailModal">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                                <!-- Lista de emails adicionales -->
                                <div id="emails-adicionales" class="mt-2"></div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <div>
                            <button type="submit" class="btn btn-success me-2">
                                <i class="fas fa-save me-1"></i>Guardar Proveedor
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="limpiarFormulario()">
                                <i class="fas fa-times me-1"></i>Cancelar
                            </button>
                        </div>
                        <div id="mensaje-validacion" class="text-danger small"></div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Modal para agregar teléfono -->
        <div class="modal fade" id="telefonoModal" tabindex="-1" aria-labelledby="telefonoModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="telefonoModalLabel">Agregar Teléfono</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Número de Teléfono</label>
                            <input type="text" class="form-control" id="nuevo-telefono" placeholder="Ingrese el número">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tipo de Teléfono</label>
                            <select class="form-select" id="tipo-telefono">
                                <option value="celular">Celular</option>
                                <option value="fijo">Fijo</option>
                                <option value="whatsapp">WhatsApp</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" onclick="agregarTelefono()">Agregar
                            Teléfono</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal para agregar email -->
        <div class="modal fade" id="emailModal" tabindex="-1" aria-labelledby="emailModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="emailModalLabel">Agregar Email</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Correo Electrónico</label>
                            <input type="email" class="form-control" id="nuevo-email" placeholder="correo@ejemplo.com">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tipo de Email</label>
                            <select class="form-select" id="tipo-email">
                                <option value="trabajo">Trabajo</option>
                                <option value="personal">Personal</option>
                                <option value="facturacion">Facturación</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" onclick="agregarEmail()">Agregar Email</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabla de proveedores -->
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Lista de Proveedores</h5>
            </div>
            <div class="card-body">
                <?php if ($proveedores->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Teléfono Principal</th>
                                    <th>Teléfonos Adicionales</th>
                                    <th>Dirección</th>
                                    <th>Email Principal</th>
                                    <th>Emails Adicionales</th>
                                    <th width="120">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Reiniciar el cursor para poder iterar nuevamente
                                $proveedores = $model->leer();
                                while ($row = $proveedores->fetch(PDO::FETCH_ASSOC)):
                                    // Obtener teléfonos y emails adicionales del proveedor
                                    $telefonosAdicionales = $model->obtenerTelefonosProveedor($row['id_proveedores']);
                                    $emailsAdicionales = $model->obtenerEmailsProveedor($row['id_proveedores']);
                                    ?>
                                    <tr>
                                        <td><code><?php echo $row['id_proveedores']; ?></code></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($row['nombre']); ?></strong>
                                        </td>
                                        <td>
                                            <?php if ($row['telefono_principal']): ?>
                                                <span class="badge bg-info">
                                                    <i class="fas fa-phone me-1"></i><?php echo $row['telefono_principal']; ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($telefonosAdicionales->rowCount() > 0): ?>
                                                <?php while ($telefono = $telefonosAdicionales->fetch(PDO::FETCH_ASSOC)): ?>
                                                    <div class="small">
                                                        <i class="fas fa-phone me-1"></i>
                                                        <?php echo $telefono['numero']; ?>
                                                        <span class="badge bg-secondary"><?php echo $telefono['tipo']; ?></span>
                                                    </div>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($row['direccion']): ?>
                                                <small><?php echo htmlspecialchars($row['direccion']); ?></small>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($row['email_principal']): ?>
                                                <a href="mailto:<?php echo $row['email_principal']; ?>"
                                                    class="text-decoration-none">
                                                    <i class="fas fa-envelope me-1"></i><?php echo $row['email_principal']; ?>
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($emailsAdicionales->rowCount() > 0): ?>
                                                <?php while ($email = $emailsAdicionales->fetch(PDO::FETCH_ASSOC)): ?>
                                                    <div class="small">
                                                        <i class="fas fa-envelope me-1"></i>
                                                        <?php echo $email['correo']; ?>
                                                        <span class="badge bg-secondary"><?php echo $email['tipo']; ?></span>
                                                    </div>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-warning me-1"
                                                onclick="editarProveedor('<?php echo $row['id_proveedores']; ?>')"
                                                title="Editar proveedor">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger"
                                                onclick="eliminarProveedor('<?php echo $row['id_proveedores']; ?>')"
                                                title="Eliminar proveedor">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle me-2"></i>No hay proveedores registrados.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Arrays para almacenar teléfonos y emails adicionales
        let telefonosAdicionales = [];
        let emailsAdicionales = [];

        // Enfocar el campo nombre al cargar la página
        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('nombre').focus();
        });

        // Validar email
        function validarEmail(email) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
        }

        // Agregar teléfono adicional
        function agregarTelefono() {
            const numero = document.getElementById('nuevo-telefono').value.trim();
            const tipo = document.getElementById('tipo-telefono').value;

            if (!numero) {
                alert('Por favor ingrese un número de teléfono');
                return;
            }

            const telefono = {
                numero: numero,
                tipo: tipo
            };

            telefonosAdicionales.push(telefono);
            actualizarListaTelefonos();

            // Limpiar y cerrar modal
            document.getElementById('nuevo-telefono').value = '';
            document.getElementById('tipo-telefono').value = 'celular';
            bootstrap.Modal.getInstance(document.getElementById('telefonoModal')).hide();
        }

        // Agregar email adicional
        function agregarEmail() {
            const correo = document.getElementById('nuevo-email').value.trim();
            const tipo = document.getElementById('tipo-email').value;

            if (!correo) {
                alert('Por favor ingrese un correo electrónico');
                return;
            }

            if (!validarEmail(correo)) {
                alert('Por favor ingrese un email válido');
                return;
            }

            const email = {
                correo: correo,
                tipo: tipo
            };

            emailsAdicionales.push(email);
            actualizarListaEmails();

            // Limpiar y cerrar modal
            document.getElementById('nuevo-email').value = '';
            document.getElementById('tipo-email').value = 'trabajo';
            bootstrap.Modal.getInstance(document.getElementById('emailModal')).hide();
        }

        // Actualizar lista visual de teléfonos
        function actualizarListaTelefonos() {
            const container = document.getElementById('telefonos-adicionales');
            container.innerHTML = '';

            telefonosAdicionales.forEach((telefono, index) => {
                const div = document.createElement('div');
                div.className = 'd-flex justify-content-between align-items-center bg-light p-2 mb-1 rounded';
                div.innerHTML = `
                    <div>
                        <i class="fas fa-phone me-1"></i>
                        ${telefono.numero}
                        <span class="badge bg-secondary">${telefono.tipo}</span>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="eliminarTelefono(${index})">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                container.appendChild(div);
            });
        }

        // Actualizar lista visual de emails
        function actualizarListaEmails() {
            const container = document.getElementById('emails-adicionales');
            container.innerHTML = '';

            emailsAdicionales.forEach((email, index) => {
                const div = document.createElement('div');
                div.className = 'd-flex justify-content-between align-items-center bg-light p-2 mb-1 rounded';
                div.innerHTML = `
                    <div>
                        <i class="fas fa-envelope me-1"></i>
                        ${email.correo}
                        <span class="badge bg-secondary">${email.tipo}</span>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="eliminarEmail(${index})">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                container.appendChild(div);
            });
        }

        // Eliminar teléfono de la lista
        function eliminarTelefono(index) {
            telefonosAdicionales.splice(index, 1);
            actualizarListaTelefonos();
        }

        // Eliminar email de la lista
        function eliminarEmail(index) {
            emailsAdicionales.splice(index, 1);
            actualizarListaEmails();
        }

        // Manejar envío del formulario
        document.getElementById('proveedor-form').addEventListener('submit', function (e) {
            e.preventDefault();

            // Validar email principal
            const emailPrincipal = document.getElementById('email_principal').value.trim();
            if (emailPrincipal && !validarEmail(emailPrincipal)) {
                alert('Por favor ingrese un email principal válido');
                return;
            }

            const formData = new FormData(this);
            const id = document.getElementById('proveedor-id').value;
            formData.append('accion', id ? 'actualizar' : 'crear');

            // Agregar teléfonos y emails adicionales al formData
            telefonosAdicionales.forEach((telefono, index) => {
                formData.append(`telefonos_adicionales[${index}][numero]`, telefono.numero);
                formData.append(`telefonos_adicionales[${index}][tipo]`, telefono.tipo);
            });

            emailsAdicionales.forEach((email, index) => {
                formData.append(`emails_adicionales[${index}][correo]`, email.correo);
                formData.append(`emails_adicionales[${index}][tipo]`, email.tipo);
            });

            // Validación básica
            const nombre = document.getElementById('nombre').value.trim();
            if (!nombre) {
                alert('Por favor ingrese el nombre del proveedor');
                document.getElementById('nombre').focus();
                return;
            }

            fetch('../../controllers/ProveedorController.php', {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al procesar la solicitud: ' + error.message);
                });
        });

        function editarProveedor(id) {
            console.log('Editando proveedor ID:', id);

            fetch('../../controllers/ProveedorController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'accion=obtener&id=' + encodeURIComponent(id)
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor: ' + response.status);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Datos recibidos:', data);

                    if (data.success === false) {
                        throw new Error(data.message || 'Error al obtener los datos');
                    }

                    if (data && data.id_proveedores) {
                        document.getElementById('proveedor-id').value = data.id_proveedores;
                        document.getElementById('nombre').value = data.nombre || '';
                        document.getElementById('telefono_principal').value = data.telefono_principal || '';
                        document.getElementById('direccion').value = data.direccion || '';
                        document.getElementById('email_principal').value = data.email_principal || '';

                        // Cargar teléfonos y emails adicionales
                        telefonosAdicionales = data.telefonos_adicionales || [];
                        emailsAdicionales = data.emails_adicionales || [];
                        actualizarListaTelefonos();
                        actualizarListaEmails();

                        document.getElementById('form-title').innerHTML = '<i class="fas fa-edit me-2"></i>Editar Proveedor';
                        document.getElementById('nombre').focus();
                    } else {
                        throw new Error('Datos del proveedor no encontrados');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al cargar los datos del proveedor: ' + error.message);
                });
        }

        function eliminarProveedor(id) {
            if (confirm('¿Está seguro de eliminar este proveedor?\n\nEsta acción no se puede deshacer.')) {
                fetch('../../controllers/ProveedorController.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'accion=eliminar&id=' + id
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error en la respuesta del servidor');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            alert(data.message);
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error al eliminar el proveedor: ' + error.message);
                    });
            }
        }

        function limpiarFormulario() {
            document.getElementById('proveedor-form').reset();
            document.getElementById('proveedor-id').value = '';
            document.getElementById('form-title').innerHTML = '<i class="fas fa-plus-circle me-2"></i>Nuevo Proveedor';
            document.getElementById('mensaje-validacion').textContent = '';

            // Limpiar listas de teléfonos y emails
            telefonosAdicionales = [];
            emailsAdicionales = [];
            actualizarListaTelefonos();
            actualizarListaEmails();

            document.getElementById('nombre').focus();
        }

        // Validar email principal en tiempo real
        document.getElementById('email_principal').addEventListener('input', function () {
            const email = this.value.trim();
            const mensaje = document.getElementById('mensaje-validacion');

            if (email && !validarEmail(email)) {
                mensaje.textContent = 'Por favor ingrese un email válido';
            } else {
                mensaje.textContent = '';
            }
        });
    </script>
</body>

</html>