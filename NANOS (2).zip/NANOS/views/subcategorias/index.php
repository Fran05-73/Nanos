<?php
include_once '../../config/database.php';
include_once '../../models/SubcategoriaModel.php';

$database = new Database();
$db = $database->getConnection();
$model = new SubcategoriaModel($db);
$subcategorias = $model->leer();
$categorias = $model->obtenerCategorias();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Subcategorías</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .table-actions {
            white-space: nowrap;
        }

        .badge-categoria {
            font-size: 0.75em;
        }
    </style>
</head>

<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-sitemap me-2"></i>Gestión de Subcategorías</h2>
            <a href="../../" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i>Volver al Inicio
            </a>
        </div>

        <!-- Formulario para crear/editar -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0" id="form-title">
                    <i class="fas fa-plus-circle me-2"></i>Nueva Subcategoría
                </h5>
            </div>
            <div class="card-body">
                <form id="subcategoria-form">
                    <input type="hidden" id="subcategoria-id" name="id">
                    <input type="hidden" id="id_subcategoria" name="id_subcategoria">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Categoría *</label>
                                <select class="form-select" id="id_categoria" name="id_categoria" required>
                                    <option value="">Seleccione una categoría</option>
                                    <?php while ($categoria = $categorias->fetch(PDO::FETCH_ASSOC)): ?>
                                        <option value="<?= $categoria['id_categoria'] ?>">
                                            <?= htmlspecialchars($categoria['nombre']) ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Nombre de Subcategoría *</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required
                                    placeholder="Ingrese el nombre de la subcategoría">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Descripción</label>
                                <input type="text" class="form-control" id="descripcion" name="descripcion"
                                    placeholder="Descripción opcional">
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <div>
                            <button type="submit" class="btn btn-success me-2">
                                <i class="fas fa-save me-1"></i>Guardar Subcategoría
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="limpiarFormulario()">
                                <i class="fas fa-times me-1"></i>Cancelar
                            </button>
                        </div>
                        <div id="mensaje-validacion" class="text-danger small"></div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tabla de subcategorías -->
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Lista de Subcategorías</h5>
            </div>
            <div class="card-body">
                <?php if ($subcategorias && $subcategorias->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Categoría</th>
                                    <th>Descripción</th>
                                    <th width="120" class="text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $subcategorias->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td><code><?= $row['id_subcategoria'] ?></code></td>
                                        <td>
                                            <strong><?= htmlspecialchars($row['nombre']) ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary badge-categoria">
                                                <?= htmlspecialchars($row['categoria_nombre']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($row['descripcion']): ?>
                                                <small class="text-muted"><?= htmlspecialchars($row['descripcion']) ?></small>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="table-actions text-center">
                                            <button class="btn btn-sm btn-warning me-1"
                                                onclick="editarSubcategoria('<?= $row['id_subcategoria'] ?>')"
                                                title="Editar subcategoría">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger"
                                                onclick="eliminarSubcategoria('<?= $row['id_subcategoria'] ?>')"
                                                title="Eliminar subcategoría">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle me-2"></i>No hay subcategorías registradas.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Enfocar el campo nombre al cargar la página
        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('nombre').focus();
        });

        // Manejar envío del formulario
        document.getElementById('subcategoria-form').addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(this);
            const id = document.getElementById('subcategoria-id').value;
            formData.append('accion', id ? 'actualizar' : 'crear');

            // Si es creación, generar ID automático
            if (!id) {
                const nuevoId = generarIdSubcategoria();
                document.getElementById('id_subcategoria').value = nuevoId;
                formData.append('id_subcategoria', nuevoId);
            }

            // Validación básica
            const nombre = document.getElementById('nombre').value.trim();
            const categoria = document.getElementById('id_categoria').value;

            if (!nombre) {
                alert('Por favor ingrese el nombre de la subcategoría');
                document.getElementById('nombre').focus();
                return;
            }

            if (!categoria) {
                alert('Por favor seleccione una categoría');
                document.getElementById('id_categoria').focus();
                return;
            }

            fetch('../../controllers/SubcategoriaController.php', {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al procesar la solicitud: ' + error.message);
                });
        });

        function editarSubcategoria(id) {
            console.log('Editando subcategoría ID:', id);

            fetch('../../controllers/SubcategoriaController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'accion=obtener&id=' + encodeURIComponent(id)
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor: ' + response.status);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Datos recibidos:', data);

                    if (data.success === false) {
                        throw new Error(data.message || 'Error al obtener los datos');
                    }

                    if (data && data.id_subcategoria) {
                        document.getElementById('subcategoria-id').value = data.id_subcategoria;
                        document.getElementById('id_subcategoria').value = data.id_subcategoria;
                        document.getElementById('id_categoria').value = data.id_categoria || '';
                        document.getElementById('nombre').value = data.nombre || '';
                        document.getElementById('descripcion').value = data.descripcion || '';

                        document.getElementById('form-title').innerHTML = '<i class="fas fa-edit me-2"></i>Editar Subcategoría';
                        document.getElementById('nombre').focus();
                    } else {
                        throw new Error('Datos de la subcategoría no encontrados');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al cargar los datos de la subcategoría: ' + error.message);
                });
        }

        function eliminarSubcategoria(id) {
            if (confirm('¿Está seguro de eliminar esta subcategoría?\n\nNota: No se podrá eliminar si está siendo usada en productos.')) {
                fetch('../../controllers/SubcategoriaController.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'accion=eliminar&id=' + id
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error en la respuesta del servidor');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            alert(data.message);
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error al eliminar la subcategoría: ' + error.message);
                    });
            }
        }

        function limpiarFormulario() {
            document.getElementById('subcategoria-form').reset();
            document.getElementById('subcategoria-id').value = '';
            document.getElementById('id_subcategoria').value = '';
            document.getElementById('form-title').innerHTML = '<i class="fas fa-plus-circle me-2"></i>Nueva Subcategoría';
            document.getElementById('mensaje-validacion').textContent = '';
            document.getElementById('nombre').focus();
        }

        // Función para generar ID automático (simulada)
        function generarIdSubcategoria() {
            // En una implementación real, esto vendría del servidor
            return 'SUB_NEW';
        }
    </script>
</body>

</html>