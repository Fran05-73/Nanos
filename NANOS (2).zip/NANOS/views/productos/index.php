<?php
include_once '../../config/database.php';
include_once '../../models/ProductoModel.php';

$database = new Database();
$db = $database->getConnection();
$model = new ProductoModel($db);
$productos = $model->leer();
$categorias = $model->obtenerCategorias();
$proveedores = $model->obtenerProveedores();
$magnitudes = $model->obtenerMagnitudes();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-boxes me-2"></i>Gestión de Productos</h2>
            <a href="../../" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i>Volver al Inicio
            </a>
        </div>

        <!-- Formulario para crear/editar -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0" id="form-title">
                    <i class="fas fa-plus-circle me-2"></i>Nuevo Producto
                </h5>
            </div>
            <div class="card-body">
                <form id="producto-form">
                    <input type="hidden" id="producto-id" name="id">

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Nombre del Producto *</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required
                                    placeholder="Ingrese el nombre del producto">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Código del Producto</label>
                                <input type="text" class="form-control" id="codigo" name="codigo"
                                    placeholder="Código único del producto (opcional)">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Descripción</label>
                                <textarea class="form-control" id="descripcion" name="descripcion" rows="3"
                                    placeholder="Descripción del producto"></textarea>
                            </div>

                            <!-- Categoría y Subcategoría -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Categoría</label>
                                        <div class="input-group">
                                            <select class="form-select" id="id_categoria" name="id_categoria">
                                                <option value="">Seleccione una categoría</option>
                                                <?php
                                                $categorias = $model->obtenerCategorias();
                                                while ($categoria = $categorias->fetch(PDO::FETCH_ASSOC)): ?>
                                                    <option value="<?php echo $categoria['id_categoria']; ?>">
                                                        <?php echo htmlspecialchars($categoria['nombre']); ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                                data-bs-target="#categoriaModal">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Subcategoría</label>
                                        <div class="input-group">
                                            <select class="form-select" id="id_subcategoria" name="id_subcategoria">
                                                <option value="">Seleccione una subcategoría</option>
                                            </select>
                                            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                                data-bs-target="#subcategoriaModal">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Precio de Venta *</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="precio_venta" name="precio_venta"
                                        step="0.01" min="0" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Stock *</label>
                                <input type="number" class="form-control" id="stock" name="stock" min="0" required
                                    placeholder="Cantidad en stock">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Fecha de Vencimiento *</label>
                                <input type="date" class="form-control" id="fecha_vencimiento" name="fecha_vencimiento"
                                    required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Proveedor</label>
                                <div class="input-group">
                                    <select class="form-select" id="id_proveedores" name="id_proveedores">
                                        <option value="">Seleccione un proveedor</option>
                                        <?php
                                        $proveedores = $model->obtenerProveedores();
                                        while ($proveedor = $proveedores->fetch(PDO::FETCH_ASSOC)): ?>
                                            <option value="<?php echo $proveedor['id_proveedores']; ?>">
                                                <?php echo htmlspecialchars($proveedor['nombre']); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#proveedorModal">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- Sección de Peso (se mostrará dinámicamente) -->
                            <div id="seccion-peso" class="d-none">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Peso</label>
                                            <input type="number" class="form-control" id="peso" name="peso" min="0"
                                                step="0.01">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Magnitud</label>
                                            <div class="input-group">
                                                <select class="form-select" id="id_magnitud" name="id_magnitud">
                                                    <option value="">Seleccione una magnitud</option>
                                                    <?php
                                                    $magnitudes = $model->obtenerMagnitudes();
                                                    while ($magnitud = $magnitudes->fetch(PDO::FETCH_ASSOC)): ?>
                                                        <option value="<?php echo $magnitud['id_magnitud']; ?>">
                                                            <?php echo htmlspecialchars($magnitud['nombre']); ?>
                                                        </option>
                                                    <?php endwhile; ?>
                                                </select>
                                                <button type="button" class="btn btn-outline-primary"
                                                    data-bs-toggle="modal" data-bs-target="#magnitudModal">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <div>
                            <button type="submit" class="btn btn-success me-2">
                                <i class="fas fa-save me-1"></i>Guardar Producto
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="limpiarFormulario()">
                                <i class="fas fa-times me-1"></i>Cancelar
                            </button>
                        </div>
                        <div id="mensaje-validacion" class="text-danger small"></div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Modal para agregar categoría -->
        <div class="modal fade" id="categoriaModal" tabindex="-1" aria-labelledby="categoriaModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="categoriaModalLabel">Agregar Nueva Categoría</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Nombre de la Categoría *</label>
                            <input type="text" class="form-control" id="nueva-categoria"
                                placeholder="Ingrese el nombre de la categoría">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" onclick="agregarCategoria()">Agregar
                            Categoría</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal para agregar subcategoría -->
        <div class="modal fade" id="subcategoriaModal" tabindex="-1" aria-labelledby="subcategoriaModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="subcategoriaModalLabel">Agregar Nueva Subcategoría</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Categoría Padre *</label>
                            <select class="form-select" id="categoria-padre">
                                <option value="">Seleccione una categoría</option>
                                <?php
                                $categorias = $model->obtenerCategorias();
                                while ($categoria = $categorias->fetch(PDO::FETCH_ASSOC)): ?>
                                    <option value="<?php echo $categoria['id_categoria']; ?>">
                                        <?php echo htmlspecialchars($categoria['nombre']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nombre de la Subcategoría *</label>
                            <input type="text" class="form-control" id="nueva-subcategoria"
                                placeholder="Ingrese el nombre de la subcategoría">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Descripción</label>
                            <textarea class="form-control" id="descripcion-subcategoria" rows="2"
                                placeholder="Descripción de la subcategoría"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" onclick="agregarSubcategoria()">Agregar
                            Subcategoría</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal para agregar proveedor -->
        <div class="modal fade" id="proveedorModal" tabindex="-1" aria-labelledby="proveedorModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="proveedorModalLabel">Agregar Nuevo Proveedor</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Nombre del Proveedor *</label>
                            <input type="text" class="form-control" id="nuevo-proveedor"
                                placeholder="Ingrese el nombre del proveedor">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Teléfono Principal</label>
                            <input type="text" class="form-control" id="telefono-proveedor"
                                placeholder="Número de teléfono">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email Principal</label>
                            <input type="email" class="form-control" id="email-proveedor"
                                placeholder="correo@ejemplo.com">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Dirección</label>
                            <input type="text" class="form-control" id="direccion-proveedor"
                                placeholder="Dirección del proveedor">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" onclick="agregarProveedor()">Agregar
                            Proveedor</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal para agregar magnitud -->
        <div class="modal fade" id="magnitudModal" tabindex="-1" aria-labelledby="magnitudModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="magnitudModalLabel">Agregar Nueva Magnitud</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Nombre *</label>
                            <input type="text" class="form-control" id="nueva-magnitud"
                                placeholder="Ingrese el nombre de la magnitud">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Abreviatura *</label>
                            <input type="text" class="form-control" id="abreviatura-magnitud"
                                placeholder="Ej: kg, g, L, ml">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tipo *</label>
                            <select class="form-select" id="tipo-magnitud">
                                <option value="peso">Peso</option>
                                <option value="volumen">Volumen</option>
                                <option value="unidad">Unidad</option>
                                <option value="longitud">Longitud</option>
                                <option value="otros">Otros</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" onclick="agregarMagnitud()">Agregar
                            Magnitud</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabla de productos -->
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Lista de Productos</h5>
            </div>
            <div class="card-body">
                <?php if ($productos->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Código</th>
                                    <th>Nombre</th>
                                    <th>Precio Venta</th>
                                    <th>Stock</th>
                                    <th>Vencimiento</th>
                                    <th>Categoría</th>
                                    <th>Subcategoría</th>
                                    <th>Peso</th>
                                    <th>Magnitud</th>
                                    <th>Proveedor</th>
                                    <th width="120">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $productos->fetch(PDO::FETCH_ASSOC)): ?>
                                    <?php
                                    // Calcular días para vencimiento
                                    $fechaVencimiento = new DateTime($row['fecha_vencimiento']);
                                    $hoy = new DateTime();
                                    $diferencia = $hoy->diff($fechaVencimiento);
                                    $dias = $diferencia->days;
                                    $estaVencido = $fechaVencimiento < $hoy;

                                    $claseFila = '';
                                    if ($estaVencido) {
                                        $claseFila = 'table-danger';
                                    } elseif ($dias <= 21) {
                                        $claseFila = 'table-warning';
                                    }

                                    $claseBadge = 'bg-success';
                                    if ($estaVencido) {
                                        $claseBadge = 'bg-danger';
                                    } elseif ($dias <= 7) {
                                        $claseBadge = 'bg-danger';
                                    } elseif ($dias <= 14) {
                                        $claseBadge = 'bg-warning';
                                    } elseif ($dias <= 21) {
                                        $claseBadge = 'bg-info';
                                    }
                                    ?>
                                    <tr class="<?php echo $claseFila; ?>">
                                        <td><code><?php echo $row['id_producto']; ?></code></td>
                                        <td>
                                            <?php if ($row['codigo']): ?>
                                                <code><?php echo htmlspecialchars($row['codigo']); ?></code>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($row['nombre']); ?></strong>
                                            <?php if ($row['descripcion']): ?>
                                                <br><small
                                                    class="text-muted"><?php echo htmlspecialchars($row['descripcion']); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span
                                                class="badge bg-success">$<?php echo number_format($row['precio_venta'], 2); ?></span>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo $row['stock'] > 10 ? 'bg-primary' : 'bg-warning'; ?>">
                                                <?php echo $row['stock']; ?> unidades
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo $claseBadge; ?>">
                                                <?php echo date('d/m/Y', strtotime($row['fecha_vencimiento'])); ?>
                                            </span>
                                            <?php if ($dias <= 21): ?>
                                                <br><small class="text-muted">(<?php echo $dias; ?> días)</small>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo $row['categoria_nombre'] ?? 'N/A'; ?></td>
                                        <td><?php echo $row['subcategoria_nombre'] ?? 'N/A'; ?></td>
                                        <td><?php echo $row['peso'] ? $row['peso'] . ' ' . ($row['magnitud_abreviatura'] ?? '') : 'N/A'; ?>
                                        </td>
                                        <td><?php echo $row['magnitud_nombre'] ?? 'N/A'; ?></td>
                                        <td><?php echo $row['proveedor_nombre'] ?? 'N/A'; ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-warning me-1"
                                                onclick="editarProducto('<?php echo $row['id_producto']; ?>')"
                                                title="Editar producto">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger"
                                                onclick="eliminarProducto('<?php echo $row['id_producto']; ?>')"
                                                title="Eliminar producto">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle me-2"></i>No hay productos registrados.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Categorías que requieren peso
        const categoriasConPeso = ['CAT_01', 'CAT_06'];
        const subcategoriasConPeso = ['SUB_03', 'SUB_05', 'SUB_06', 'SUB_07', 'SUB_24', 'SUB_25'];

        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('nombre').focus();
            const hoy = new Date().toISOString().split('T')[0];
            document.getElementById('fecha_vencimiento').min = hoy;

            // Cargar subcategorías cuando cambie la categoría
            document.getElementById('id_categoria').addEventListener('change', function () {
                cargarSubcategorias(this.value);
                mostrarOcultarPeso(this.value);
            });
        });

        // Cargar subcategorías según categoría seleccionada
        function cargarSubcategorias(idCategoria) {
            const selectSubcategoria = document.getElementById('id_subcategoria');
            selectSubcategoria.innerHTML = '<option value="">Seleccione una subcategoría</option>';

            if (!idCategoria) return;

            fetch('../../controllers/ProductoController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'accion=obtener_subcategorias&id_categoria=' + idCategoria
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.subcategorias) {
                        data.subcategorias.forEach(subcategoria => {
                            const option = document.createElement('option');
                            option.value = subcategoria.id_subcategoria;
                            option.textContent = subcategoria.nombre;
                            selectSubcategoria.appendChild(option);
                        });
                    }
                })
                .catch(error => {
                    console.error('Error al cargar subcategorías:', error);
                });
        }

        // Mostrar u ocultar sección de peso según categoría
        function mostrarOcultarPeso(idCategoria) {
            const seccionPeso = document.getElementById('seccion-peso');

            if (categoriasConPeso.includes(idCategoria)) {
                seccionPeso.classList.remove('d-none');
            } else {
                seccionPeso.classList.add('d-none');
                document.getElementById('peso').value = '';
                document.getElementById('id_magnitud').value = '';
            }
        }

        // Función para agregar categoría
        function agregarCategoria() {
            const nombre = document.getElementById('nueva-categoria').value.trim();

            if (!nombre) {
                alert('Por favor ingrese el nombre de la categoría');
                return;
            }

            fetch('../../controllers/ProductoController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'accion=agregar_categoria&nombre=' + encodeURIComponent(nombre)
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Agregar la nueva categoría al select
                        const select = document.getElementById('id_categoria');
                        const option = document.createElement('option');
                        option.value = data.id;
                        option.textContent = nombre;
                        select.appendChild(option);

                        // Seleccionar la nueva categoría
                        select.value = data.id;

                        // Cerrar modal y limpiar
                        bootstrap.Modal.getInstance(document.getElementById('categoriaModal')).hide();
                        document.getElementById('nueva-categoria').value = '';

                        alert('Categoría agregada correctamente');
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al agregar la categoría');
                });
        }

        // Función para agregar subcategoría
        function agregarSubcategoria() {
            const idCategoria = document.getElementById('categoria-padre').value;
            const nombre = document.getElementById('nueva-subcategoria').value.trim();
            const descripcion = document.getElementById('descripcion-subcategoria').value.trim();

            if (!idCategoria) {
                alert('Por favor seleccione una categoría padre');
                return;
            }

            if (!nombre) {
                alert('Por favor ingrese el nombre de la subcategoría');
                return;
            }

            const formData = new FormData();
            formData.append('accion', 'agregar_subcategoria');
            formData.append('id_categoria', idCategoria);
            formData.append('nombre', nombre);
            formData.append('descripcion', descripcion);

            fetch('../../controllers/ProductoController.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Si la categoría seleccionada en el formulario es la misma, actualizar subcategorías
                        const categoriaActual = document.getElementById('id_categoria').value;
                        if (categoriaActual === idCategoria) {
                            cargarSubcategorias(idCategoria);
                        }

                        // Cerrar modal y limpiar
                        bootstrap.Modal.getInstance(document.getElementById('subcategoriaModal')).hide();
                        document.getElementById('nueva-subcategoria').value = '';
                        document.getElementById('descripcion-subcategoria').value = '';

                        alert('Subcategoría agregada correctamente');
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al agregar la subcategoría');
                });
        }

        // Función para agregar proveedor
        function agregarProveedor() {
            const nombre = document.getElementById('nuevo-proveedor').value.trim();
            const telefono = document.getElementById('telefono-proveedor').value.trim();
            const email = document.getElementById('email-proveedor').value.trim();
            const direccion = document.getElementById('direccion-proveedor').value.trim();

            if (!nombre) {
                alert('Por favor ingrese el nombre del proveedor');
                return;
            }

            const formData = new FormData();
            formData.append('accion', 'agregar_proveedor');
            formData.append('nombre', nombre);
            formData.append('telefono_principal', telefono);
            formData.append('email_principal', email);
            formData.append('direccion', direccion);

            fetch('../../controllers/ProductoController.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Agregar el nuevo proveedor al select
                        const select = document.getElementById('id_proveedores');
                        const option = document.createElement('option');
                        option.value = data.id;
                        option.textContent = nombre;
                        select.appendChild(option);

                        // Seleccionar el nuevo proveedor
                        select.value = data.id;

                        // Cerrar modal y limpiar
                        bootstrap.Modal.getInstance(document.getElementById('proveedorModal')).hide();
                        document.getElementById('nuevo-proveedor').value = '';
                        document.getElementById('telefono-proveedor').value = '';
                        document.getElementById('email-proveedor').value = '';
                        document.getElementById('direccion-proveedor').value = '';

                        alert('Proveedor agregado correctamente');
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al agregar el proveedor');
                });
        }

        // Función para agregar magnitud
        function agregarMagnitud() {
            const nombre = document.getElementById('nueva-magnitud').value.trim();
            const abreviatura = document.getElementById('abreviatura-magnitud').value.trim();
            const tipo = document.getElementById('tipo-magnitud').value;

            if (!nombre) {
                alert('Por favor ingrese el nombre de la magnitud');
                return;
            }

            if (!abreviatura) {
                alert('Por favor ingrese la abreviatura');
                return;
            }

            const formData = new FormData();
            formData.append('accion', 'agregar_magnitud');
            formData.append('nombre', nombre);
            formData.append('abreviatura', abreviatura);
            formData.append('tipo', tipo);

            fetch('../../controllers/ProductoController.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Agregar la nueva magnitud al select
                        const select = document.getElementById('id_magnitud');
                        const option = document.createElement('option');
                        option.value = data.id;
                        option.textContent = nombre;
                        select.appendChild(option);

                        // Seleccionar la nueva magnitud
                        select.value = data.id;

                        // Cerrar modal y limpiar
                        bootstrap.Modal.getInstance(document.getElementById('magnitudModal')).hide();
                        document.getElementById('nueva-magnitud').value = '';
                        document.getElementById('abreviatura-magnitud').value = '';

                        alert('Magnitud agregada correctamente');
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al agregar la magnitud');
                });
        }

        // Manejar envío del formulario
        document.getElementById('producto-form').addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(this);
            const id = document.getElementById('producto-id').value;
            formData.append('accion', id ? 'actualizar' : 'crear');

            // Validación básica
            const nombre = document.getElementById('nombre').value.trim();
            const precioVenta = document.getElementById('precio_venta').value;
            const stock = document.getElementById('stock').value;
            const fechaVencimiento = document.getElementById('fecha_vencimiento').value;

            if (!nombre) {
                alert('Por favor ingrese el nombre del producto');
                document.getElementById('nombre').focus();
                return;
            }

            if (!precioVenta || parseFloat(precioVenta) < 0) {
                alert('Por favor ingrese un precio de venta válido');
                document.getElementById('precio_venta').focus();
                return;
            }

            if (!stock || parseInt(stock) < 0) {
                alert('Por favor ingrese un stock válido');
                document.getElementById('stock').focus();
                return;
            }

            if (!fechaVencimiento) {
                alert('Por favor seleccione la fecha de vencimiento');
                document.getElementById('fecha_vencimiento').focus();
                return;
            }

            fetch('../../controllers/ProductoController.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al procesar la solicitud');
                });
        });

        function editarProducto(id) {
            fetch('../../controllers/ProductoController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'accion=obtener&id=' + id
            })
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        document.getElementById('producto-id').value = data.id_producto;
                        document.getElementById('codigo').value = data.codigo || '';
                        document.getElementById('nombre').value = data.nombre;
                        document.getElementById('descripcion').value = data.descripcion || '';
                        document.getElementById('precio_venta').value = data.precio_venta;
                        document.getElementById('stock').value = data.stock;
                        document.getElementById('id_categoria').value = data.id_categoria || '';
                        document.getElementById('id_proveedores').value = data.id_proveedores || '';
                        document.getElementById('peso').value = data.peso || '';
                        document.getElementById('id_magnitud').value = data.id_magnitud || '';
                        document.getElementById('id_subcategoria').value = data.id_subcategoria || '';

                        // Cargar subcategorías y mostrar/ocultar peso
                        if (data.id_categoria) {
                            cargarSubcategorias(data.id_categoria).then(() => {
                                document.getElementById('id_subcategoria').value = data.id_subcategoria || '';
                            });
                            mostrarOcultarPeso(data.id_categoria);
                        }

                        // Formatear fecha
                        if (data.fecha_vencimiento) {
                            const fecha = new Date(data.fecha_vencimiento);
                            const fechaFormateada = fecha.toISOString().split('T')[0];
                            document.getElementById('fecha_vencimiento').value = fechaFormateada;
                        }

                        document.getElementById('form-title').innerHTML = '<i class="fas fa-edit me-2"></i>Editar Producto';
                        document.getElementById('nombre').focus();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al cargar los datos del producto');
                });
        }

        function eliminarProducto(id) {
            if (confirm('¿Está seguro de eliminar este producto?\n\nEsta acción no se puede deshacer.')) {
                fetch('../../controllers/ProductoController.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'accion=eliminar&id=' + id
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(data.message);
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error al eliminar el producto');
                    });
            }
        }

        function limpiarFormulario() {
            document.getElementById('producto-form').reset();
            document.getElementById('producto-id').value = '';
            document.getElementById('form-title').innerHTML = '<i class="fas fa-plus-circle me-2"></i>Nuevo Producto';
            document.getElementById('mensaje-validacion').textContent = '';
            document.getElementById('id_subcategoria').innerHTML = '<option value="">Seleccione una subcategoría</option>';
            document.getElementById('seccion-peso').classList.add('d-none');

            const hoy = new Date().toISOString().split('T')[0];
            document.getElementById('fecha_vencimiento').min = hoy;

            document.getElementById('nombre').focus();
        }
    </script>
</body>

</html>