<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Sistema de Gestión - NANOS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .card:hover {
            transform: translateY(-5px);
            transition: transform 0.3s ease;
        }

        .feature-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
    </style>
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-store me-2"></i>Sistema NANOS
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row text-center mb-4">
            <div class="col">
                <h1 class="display-4 text-primary">Sistema de Gestión</h1>
                <p class="lead">Minisuper NANOS</p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card h-100 border-primary">
                    <div class="card-body text-center">
                        <div class="feature-icon text-primary">
                            <i class="fas fa-truck"></i>
                        </div>
                        <h5 class="card-title">Proveedores</h5>
                        <p class="card-text">Gestión completa de proveedores, contactos y información comercial.</p>
                        <a href="views/proveedores/" class="btn btn-primary">
                            <i class="fas fa-external-link-alt me-1"></i>Acceder
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card h-100 border-success">
                    <div class="card-body text-center">
                        <div class="feature-icon text-success">
                            <i class="fas fa-tags"></i>
                        </div>
                        <h5 class="card-title">Categorías</h5>
                        <p class="card-text">Organización y clasificación de productos por categorías.</p>
                        <a href="views/categorias/" class="btn btn-success">
                            <i class="fas fa-external-link-alt me-1"></i>Acceder
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card h-100 border-info">
                    <div class="card-body text-center">
                        <div class="feature-icon text-info">
                            <i class="fas fa-sitemap"></i>
                        </div>
                        <h5 class="card-title">Subcategorías</h5>
                        <p class="card-text">Gestión de subcategorías y su relación con categorías.</p>
                        <a href="views/subcategorias/" class="btn btn-info">
                            <i class="fas fa-external-link-alt me-1"></i>Acceder
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card h-100 border-info">
                    <div class="card-body text-center">
                        <div class="feature-icon text-info">
                            <i class="fas fa-weight-scale"></i>
                        </div>
                        <h5 class="card-title">Magnitudes</h5>
                        <p class="card-text">Gestión de unidades de medida: peso, volumen, unidades, etc.</p>
                        <a href="views/magnitudes/" class="btn btn-info">
                            <i class="fas fa-external-link-alt me-1"></i>Acceder
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card h-100 border-warning">
                    <div class="card-body text-center">
                        <div class="feature-icon text-warning">
                            <i class="fas fa-boxes"></i>
                        </div>
                        <h5 class="card-title">Productos</h5>
                        <p class="card-text">Administración completa del inventario de productos.</p>
                        <a href="views/productos/" class="btn btn-warning">
                            <i class="fas fa-external-link-alt me-1"></i>Acceder
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!--<div class="row mt-5">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-info-circle me-2"></i>Información del Sistema</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <ul class="list-group">
                                    <li class="list-group-item">
                                        <i class="fas fa-database me-2 text-primary"></i>
                                        Base de datos: MySQL (MariaDB)
                                    </li>
                                    <li class="list-group-item">
                                        <i class="fas fa-code me-2 text-primary"></i>
                                        Backend: PHP PDO
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="list-group">
                                    <li class="list-group-item">
                                        <i class="fas fa-palette me-2 text-primary"></i>
                                        Frontend: Bootstrap 5
                                    </li>
                                    <li class="list-group-item">
                                        <i class="fas fa-icons me-2 text-primary"></i>
                                        Iconos: Font Awesome
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->
    </div>

    <footer class="bg-dark text-light mt-5 py-3">
        <div class="container text-center">
            <p class="mb-0">&copy; 2025 Sistema NANOS. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>

</html>