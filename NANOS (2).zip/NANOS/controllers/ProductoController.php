<?php
include_once '../config/database.php';
include_once '../models/ProductoModel.php';

class ProductoController
{
    private $db;
    private $model;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->model = new ProductoModel($this->db);
    }

    public function listar()
    {
        $stmt = $this->model->leer();
        return $stmt;
    }

    public function crear($data)
    {
        return $this->model->crear($data);
    }

    public function obtener($id)
    {
        return $this->model->leerUno($id);
    }

    public function actualizar($data)
    {
        return $this->model->actualizar($data);
    }

    public function eliminar($id)
    {
        return $this->model->eliminar($id);
    }

    public function obtenerCategorias()
    {
        return $this->model->obtenerCategorias();
    }

    public function obtenerProveedores()
    {
        return $this->model->obtenerProveedores();
    }

    public function obtenerMagnitudes()
    {
        return $this->model->obtenerMagnitudes();
    }

    public function obtenerSubcategorias($id_categoria)
    {
        return $this->model->obtenerSubcategorias($id_categoria);
    }

    public function agregarCategoria($nombre)
    {
        return $this->model->agregarCategoria($nombre);
    }

    public function agregarSubcategoria($data)
    {
        return $this->model->agregarSubcategoria($data);
    }

    public function agregarProveedor($data)
    {
        return $this->model->agregarProveedor($data);
    }

    public function agregarMagnitud($data)
    {
        return $this->model->agregarMagnitud($data);
    }
}

// Manejo de solicitudes
if ($_POST) {
    $controller = new ProductoController();
    $accion = $_POST['accion'] ?? '';

    // Establecer cabecera JSON
    header('Content-Type: application/json');

    switch ($accion) {
        case 'crear':
            $data = [
                'nombre' => $_POST['nombre'] ?? '',
                'codigo' => $_POST['codigo'] ?? '',
                'descripcion' => $_POST['descripcion'] ?? '',
                'precio_venta' => $_POST['precio_venta'] ?? 0,
                'stock' => $_POST['stock'] ?? 0,
                'id_proveedores' => $_POST['id_proveedores'] ?? '',
                'id_categoria' => $_POST['id_categoria'] ?? '',
                'id_subcategoria' => $_POST['id_subcategoria'] ?? '',
                'peso' => $_POST['peso'] ?? '',
                'id_magnitud' => $_POST['id_magnitud'] ?? '',
                'fecha_vencimiento' => $_POST['fecha_vencimiento'] ?? ''
            ];

            $result = $controller->crear($data);
            if ($result['success']) {
                echo json_encode(['success' => true, 'message' => 'Producto creado correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al crear producto: ' . $result['message']]);
            }
            break;

        case 'actualizar':
            $data = [
                'id_producto' => $_POST['id'] ?? '',
                'nombre' => $_POST['nombre'] ?? '',
                'codigo' => $_POST['codigo'] ?? '',
                'descripcion' => $_POST['descripcion'] ?? '',
                'precio_venta' => $_POST['precio_venta'] ?? 0,
                'stock' => $_POST['stock'] ?? 0,
                'id_proveedores' => $_POST['id_proveedores'] ?? '',
                'id_categoria' => $_POST['id_categoria'] ?? '',
                'id_subcategoria' => $_POST['id_subcategoria'] ?? '',
                'peso' => $_POST['peso'] ?? '',
                'id_magnitud' => $_POST['id_magnitud'] ?? '',
                'fecha_vencimiento' => $_POST['fecha_vencimiento'] ?? ''
            ];

            $result = $controller->actualizar($data);
            if ($result['success']) {
                echo json_encode(['success' => true, 'message' => 'Producto actualizado correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al actualizar producto: ' . $result['message']]);
            }
            break;

        case 'eliminar':
            if ($controller->eliminar($_POST['id'])) {
                echo json_encode(['success' => true, 'message' => 'Producto eliminado correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al eliminar producto']);
            }
            break;

        case 'obtener':
            $producto = $controller->obtener($_POST['id']);
            echo json_encode($producto);
            break;

        case 'obtener_opciones':
            $categorias = $controller->obtenerCategorias();
            $proveedores = $controller->obtenerProveedores();
            $magnitudes = $controller->obtenerMagnitudes();

            $opciones = [
                'categorias' => $categorias->fetchAll(PDO::FETCH_ASSOC),
                'proveedores' => $proveedores->fetchAll(PDO::FETCH_ASSOC),
                'magnitudes' => $magnitudes->fetchAll(PDO::FETCH_ASSOC)
            ];
            echo json_encode($opciones);
            break;

        case 'obtener_subcategorias':
            $id_categoria = $_POST['id_categoria'] ?? '';
            $subcategorias = $controller->obtenerSubcategorias($id_categoria);
            $subcategoriasArray = $subcategorias->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'subcategorias' => $subcategoriasArray]);
            break;

        case 'agregar_categoria':
            $nombre = $_POST['nombre'] ?? '';
            if (empty($nombre)) {
                echo json_encode(['success' => false, 'message' => 'El nombre de la categoría es requerido']);
                break;
            }

            $result = $controller->agregarCategoria($nombre);
            if ($result['success']) {
                echo json_encode(['success' => true, 'id' => $result['id'], 'message' => 'Categoría agregada correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al agregar categoría: ' . $result['message']]);
            }
            break;

        case 'agregar_subcategoria':
            $data = [
                'id_categoria' => $_POST['id_categoria'] ?? '',
                'nombre' => $_POST['nombre'] ?? '',
                'descripcion' => $_POST['descripcion'] ?? ''
            ];

            if (empty($data['id_categoria']) || empty($data['nombre'])) {
                echo json_encode(['success' => false, 'message' => 'La categoría padre y el nombre son requeridos']);
                break;
            }

            $result = $controller->agregarSubcategoria($data);
            if ($result['success']) {
                echo json_encode(['success' => true, 'id' => $result['id'], 'message' => 'Subcategoría agregada correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al agregar subcategoría: ' . $result['message']]);
            }
            break;

        case 'agregar_proveedor':
            $data = [
                'nombre' => $_POST['nombre'] ?? '',
                'telefono_principal' => $_POST['telefono_principal'] ?? '',
                'email_principal' => $_POST['email_principal'] ?? '',
                'direccion' => $_POST['direccion'] ?? ''
            ];

            if (empty($data['nombre'])) {
                echo json_encode(['success' => false, 'message' => 'El nombre del proveedor es requerido']);
                break;
            }

            $result = $controller->agregarProveedor($data);
            if ($result['success']) {
                echo json_encode(['success' => true, 'id' => $result['id'], 'message' => 'Proveedor agregado correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al agregar proveedor: ' . $result['message']]);
            }
            break;

        case 'agregar_magnitud':
            $data = [
                'nombre' => $_POST['nombre'] ?? '',
                'abreviatura' => $_POST['abreviatura'] ?? '',
                'tipo' => $_POST['tipo'] ?? 'unidad'
            ];

            if (empty($data['nombre']) || empty($data['abreviatura'])) {
                echo json_encode(['success' => false, 'message' => 'El nombre y la abreviatura son requeridos']);
                break;
            }

            $result = $controller->agregarMagnitud($data);
            if ($result['success']) {
                echo json_encode(['success' => true, 'id' => $result['id'], 'message' => 'Magnitud agregada correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al agregar magnitud: ' . $result['message']]);
            }
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Acción no válida']);
            break;
    }
} else {
    // Si no es POST, devolver error
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
}
?>