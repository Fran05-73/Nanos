<?php
include_once '../config/database.php';
include_once '../models/ProveedorModel.php';

class ProveedorController
{
    private $db;
    private $model;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->model = new ProveedorModel($this->db);
    }

    public function listar()
    {
        $stmt = $this->model->leer();
        return $stmt;
    }

    public function crear($data)
    {
        return $this->model->crear($data);
    }

    public function obtener($id)
    {
        return $this->model->leerUno($id);
    }

    public function actualizar($data)
    {
        return $this->model->actualizar($data);
    }

    public function eliminar($id)
    {
        return $this->model->eliminar($id);
    }
}

// Manejo de solicitudes
if ($_POST) {
    $controller = new ProveedorController();
    $accion = $_POST['accion'] ?? '';

    // Establecer cabecera JSON
    header('Content-Type: application/json');

    switch ($accion) {
        case 'crear':
            $data = [
                'nombre' => $_POST['nombre'] ?? '',
                'telefono_principal' => $_POST['telefono_principal'] ?? '',
                'direccion' => $_POST['direccion'] ?? '',
                'email_principal' => $_POST['email_principal'] ?? '',
                'telefonos_adicionales' => $_POST['telefonos_adicionales'] ?? [],
                'emails_adicionales' => $_POST['emails_adicionales'] ?? []
            ];

            $result = $controller->crear($data);
            if ($result['success']) {
                echo json_encode(['success' => true, 'message' => 'Proveedor creado correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al crear proveedor: ' . $result['message']]);
            }
            break;

        case 'actualizar':
            $data = [
                'id_proveedores' => $_POST['id'] ?? '',
                'nombre' => $_POST['nombre'] ?? '',
                'telefono_principal' => $_POST['telefono_principal'] ?? '',
                'direccion' => $_POST['direccion'] ?? '',
                'email_principal' => $_POST['email_principal'] ?? '',
                'telefonos_adicionales' => $_POST['telefonos_adicionales'] ?? [],
                'emails_adicionales' => $_POST['emails_adicionales'] ?? []
            ];

            $result = $controller->actualizar($data);
            if ($result['success']) {
                echo json_encode(['success' => true, 'message' => 'Proveedor actualizado correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al actualizar proveedor: ' . $result['message']]);
            }
            break;

        case 'obtener':
            $proveedor = $controller->obtener($_POST['id']);
            if ($proveedor) {
                echo json_encode($proveedor);
            } else {
                echo json_encode(['success' => false, 'message' => 'Proveedor no encontrado']);
            }
            break;

        case 'eliminar':
            if ($controller->eliminar($_POST['id'])) {
                echo json_encode(['success' => true, 'message' => 'Proveedor eliminado correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al eliminar proveedor']);
            }
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Acción no válida']);
            break;
    }
} else {
    // Si no es POST, devolver error
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
}
?>