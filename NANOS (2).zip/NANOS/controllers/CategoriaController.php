<?php
include_once '../config/database.php';
include_once '../models/CategoriaModel.php';

class CategoriaController
{
    private $db;
    private $model;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->model = new CategoriaModel($this->db);
    }

    public function listar()
    {
        $stmt = $this->model->leer();
        return $stmt;
    }

    public function crear($data)
    {
        return $this->model->crear($data);
    }

    public function obtener($id)
    {
        return $this->model->leerUno($id);
    }

    public function actualizar($data)
    {
        return $this->model->actualizar($data);
    }

    public function eliminar($id)
    {
        return $this->model->eliminar($id);
    }
}

// Manejo de solicitudes
if ($_POST) {
    $controller = new CategoriaController();
    $accion = $_POST['accion'] ?? '';

    switch ($accion) {
        case 'crear':
            $data = [
                'nombre' => $_POST['nombre']
            ];
            if ($controller->crear($data)) {
                echo json_encode(['success' => true, 'message' => 'Categoría creada correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al crear categoría']);
            }
            break;

        case 'actualizar':
            $data = [
                'id_categoria' => $_POST['id'],
                'nombre' => $_POST['nombre']
            ];
            if ($controller->actualizar($data)) {
                echo json_encode(['success' => true, 'message' => 'Categoría actualizada correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al actualizar categoría']);
            }
            break;

        case 'eliminar':
            if ($controller->eliminar($_POST['id'])) {
                echo json_encode(['success' => true, 'message' => 'Categoría eliminada correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al eliminar categoría']);
            }
            break;

        case 'obtener':
            $categoria = $controller->obtener($_POST['id']);
            echo json_encode($categoria);
            break;
    }
}
?>