<?php
include_once '../config/database.php';
include_once '../models/SubcategoriaModel.php';

class SubcategoriaController
{
    private $db;
    private $model;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->model = new SubcategoriaModel($this->db);
    }

    public function listar()
    {
        $stmt = $this->model->leer();
        return $stmt;
    }

    public function crear($data)
    {
        return $this->model->crear($data);
    }

    public function obtener($id)
    {
        return $this->model->leerUno($id);
    }

    public function actualizar($data)
    {
        return $this->model->actualizar($data);
    }

    public function eliminar($id)
    {
        return $this->model->eliminar($id);
    }

    public function obtenerCategorias()
    {
        return $this->model->obtenerCategorias();
    }
}

// Manejo de solicitudes
if ($_POST) {
    $controller = new SubcategoriaController();
    $accion = $_POST['accion'] ?? '';

    // Establecer cabecera JSON
    header('Content-Type: application/json');

    switch ($accion) {
        case 'crear':
            $data = [
                'id_subcategoria' => $_POST['id_subcategoria'] ?? '',
                'id_categoria' => $_POST['id_categoria'] ?? '',
                'nombre' => $_POST['nombre'] ?? '',
                'descripcion' => $_POST['descripcion'] ?? ''
            ];

            $result = $controller->crear($data);
            if ($result['success']) {
                echo json_encode(['success' => true, 'message' => 'Subcategoría creada correctamente', 'id' => $result['id']]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al crear subcategoría: ' . $result['message']]);
            }
            break;

        case 'actualizar':
            $data = [
                'id_subcategoria' => $_POST['id'] ?? '',
                'id_categoria' => $_POST['id_categoria'] ?? '',
                'nombre' => $_POST['nombre'] ?? '',
                'descripcion' => $_POST['descripcion'] ?? ''
            ];

            $result = $controller->actualizar($data);
            if ($result['success']) {
                echo json_encode(['success' => true, 'message' => 'Subcategoría actualizada correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al actualizar subcategoría: ' . $result['message']]);
            }
            break;

        case 'obtener':
            $subcategoria = $controller->obtener($_POST['id']);
            if ($subcategoria) {
                echo json_encode($subcategoria);
            } else {
                echo json_encode(['success' => false, 'message' => 'Subcategoría no encontrada']);
            }
            break;

        case 'eliminar':
            $result = $controller->eliminar($_POST['id']);
            if ($result['success']) {
                echo json_encode(['success' => true, 'message' => 'Subcategoría eliminada correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al eliminar subcategoría: ' . $result['message']]);
            }
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Acción no válida']);
            break;
    }
} else {
    // Si no es POST, devolver error
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
}
?>